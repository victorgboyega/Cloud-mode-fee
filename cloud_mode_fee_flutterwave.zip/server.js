require("dotenv").config();
const express = require("express");
const path = require("path");
const crypto = require("crypto");

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/create-payment", async (req, res) => {
  try {
    const { name, email, reference, amount } = req.body;
    const numericAmount = Number(amount);

    if (!name || !email || !reference || !Number.isFinite(numericAmount) || numericAmount <= 0) {
      return res.status(400).json({ error: "Please provide valid payment details." });
    }
    if (!process.env.FLW_SECRET_KEY || process.env.FLW_SECRET_KEY.includes("your-test-secret-key")) {
      return res.status(500).json({ error: "Flutterwave secret key is not configured on the server." });
    }

    const tx_ref = `CMF-${Date.now()}-${crypto.randomBytes(4).toString("hex")}`;
    const base = process.env.PUBLIC_URL || `http://localhost:${process.env.PORT || 3000}`;

    const response = await fetch("https://api.flutterwave.com/v3/payments", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.FLW_SECRET_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        tx_ref,
        amount: numericAmount,
        currency: "NGN",
        redirect_url: `${base}/payment-callback`,
        payment_options: "card, account, banktransfer, ussd, nqr, enaira, opay",
        customer: { name, email },
        customizations: {
          title: "Cloud Mode Fee",
          description: reference
        },
        meta: { payment_reference: reference }
      })
    });

    const data = await response.json();
    if (!response.ok || data.status !== "success") {
      return res.status(502).json({ error: data.message || "Could not initialize payment." });
    }
    res.json({ link: data.data.link });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Payment initialization failed." });
  }
});

app.get("/payment-callback", (req, res) => {
  const { status, tx_ref, transaction_id } = req.query;
  res.send(`<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Cloud Mode Fee</title></head>
  <body style="font-family:Arial;text-align:center;padding:60px">
  <h1>${status === "successful" ? "Payment submitted" : "Payment not completed"}</h1>
  <p>Reference: ${tx_ref || "N/A"}</p>
  <p>Transaction ID: ${transaction_id || "N/A"}</p>
  <p><strong>Important:</strong> verify the transaction on the server before treating it as paid.</p>
  <a href="/">Return to Cloud Mode Fee</a></body></html>`);
});

app.listen(process.env.PORT || 3000, () => console.log("Cloud Mode Fee running"));
